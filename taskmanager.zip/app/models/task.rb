class Task < ApplicationRecord
end
